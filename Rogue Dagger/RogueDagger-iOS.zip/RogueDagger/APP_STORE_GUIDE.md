# Rogue Dagger — App Store Submission Guide

This folder is a ready-to-build iOS project. The game lives in `www/index.html`;
`ios/` is the Xcode project that wraps it as a native app (Capacitor 8, Swift
Package Manager — no CocoaPods needed).

Already set up for you:
- App name **Rogue Dagger**, bundle ID `com.daggersedge.roguedagger` (change it if you like — see step 3)
- Pixel-art app icon (1024×1024, no transparency) and black launch screen
- Portrait and landscape, full screen, status bar hidden
- Export-compliance flag set (no encryption), so you won't be asked every upload
- Game saves progress/settings on the device, pauses when the app is backgrounded,
  works offline, and collects no data

---

## What you need
1. **A Mac** with the latest **Xcode** (free, Mac App Store).
2. **An Apple Developer Program membership** — $99/year at developer.apple.com/programs.
   Enrollment can take a day or two to be approved.
3. **An iPhone** for a real-device test (strongly recommended before submitting).

## Steps

### 1. Open the project
Unzip this folder on your Mac, then double-click `ios/App/App.xcodeproj`.
Xcode will download the Capacitor package the first time (takes a minute).

### 2. Sign it
Click the blue **App** project in the left sidebar → **App** target → **Signing & Capabilities**:
- Tick **Automatically manage signing**
- Pick your **Team** (your developer account)

### 3. (Optional) change the bundle ID
Same screen, **Bundle Identifier**. It must be unique worldwide, e.g.
`com.yourname.roguedagger`. If you change it, also change `appId` in
`capacitor.config.json` so future syncs match.

### 4. Test on your iPhone
Plug in your iPhone, pick it as the run destination at the top of Xcode, press ▶.
Play through at least one full rush on each difficulty and both characters.
Check: music, the upload-your-own-song picker, pausing when you swipe home, and
that your unlocked artifacts are still there after closing and reopening.

### 5. Create the app listing
At **appstoreconnect.apple.com** → My Apps → **+** → New App:
- Platform iOS, name **Rogue Dagger** (if taken, try "Rogue Dagger: Boss Rush"),
  your bundle ID, SKU anything (e.g. `roguedagger001`)
- Fill in the listing using `APP_STORE_LISTING.md` in this folder
- **App Privacy** → "Data Not Collected"
- **Privacy Policy URL** — required even when you collect nothing. Host the text from
  `PRIVACY_POLICY.md` anywhere public (a GitHub Pages page or a free Notion/Google
  Sites page works) and paste the link
- **Age Rating** questionnaire — answer "Infrequent/Mild" for Cartoon or Fantasy
  Violence and "No" to everything else

### 6. Screenshots
Required: 6.9" iPhone screenshots (1320×2868). Easiest way: run the game in the
**iPhone 16 Pro Max / 17 Pro Max simulator** in Xcode, press **⌘S** to save a
screenshot. Grab 3–5: title cutscene, a boss fight mid-bullet-storm, character
select, rush select, a boss entrance. Apple scales them for smaller iPhones.
The project allows iPad too; if you'd rather not make iPad screenshots, set the
target's **Supported Destinations** to iPhone only before uploading.

### 7. Upload the build
In Xcode: set the destination to **Any iOS Device (arm64)** → **Product → Archive**.
When the Organizer opens, **Distribute App → App Store Connect → Upload**.
After ~15 minutes it appears under your app's **TestFlight** tab.

### 8. Submit
On your app's page in App Store Connect, pick the uploaded build, add the
screenshots, and click **Add for Review → Submit**. Reviews usually take 1–3 days.

---

## Updating the game later
1. Replace `www/index.html` with the new version of the game.
2. In Terminal in this folder: `npm install` (first time only), then `npx cap sync ios`.
3. In Xcode, bump **Version** (e.g. 1.0.1) or **Build** number, then Archive and upload again.

## Review notes worth knowing
- Apple sometimes rejects apps that are "just a website." This is a complete, offline
  game with no web browsing, so it should be fine; if a reviewer asks, reply that all
  content is bundled in the app and it plays fully offline.
- The "Upload your own song" feature only plays files the player picks from their own
  device and never uploads them anywhere — mention this in the review notes if asked.
