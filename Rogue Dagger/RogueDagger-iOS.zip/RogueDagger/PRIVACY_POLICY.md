# Rogue Dagger — Privacy Policy

*Last updated: October 26, 2026*

Rogue Dagger does not collect, store, or share any personal information.

- **No accounts, no tracking, no ads, no analytics.** The game has no servers and makes no network requests.
- **Game progress and settings** (unlocked artifacts, difficulty, selected character, rush and music track) are saved only on your device and never leave it. Deleting the app deletes this data.
- **Your own music:** if you choose to play your own song, the game reads the audio file you pick from your device only to play it during that session. The file is not copied, uploaded, or shared.

**Children:** The game does not knowingly collect information from anyone, including children.

**Changes:** If this policy ever changes, the updated version will be posted at this address.

**Contact:** [your contact email]
