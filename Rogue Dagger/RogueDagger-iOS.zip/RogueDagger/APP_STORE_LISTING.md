# App Store Listing — Rogue Dagger

**Name (30 chars max):** Rogue Dagger

**Subtitle (30 chars max):** Pixel Bullet-Hell Boss Rush

**Category:** Games → Action (secondary: Arcade)

**Price:** Free (or your choice)

**Promotional text (170 chars max):**
Nine bosses. Three cursed lands. One tiny hero. Dodge storms of bullets and carve through a pixel-art boss rush — on Easy, Standard, or one-life Hard.

**Description:**
Rogue Dagger is a bite-sized bullet-hell boss rush in classic pixel style.

Fight through three themed rushes — the Jungle Depths, the Sunbaked Wastes and the Frostbound Spire — each with three hand-crafted bosses and a towering finale that combines everything before it. Every boss has its own entrance, three escalating phases and a growing repertoire of attack patterns.

• Two heroes: the Rogue, who throws a steady stream of daggers, and the Wizard, who charges devastating arcane blasts
• Dash through danger and time your Cloak to block a killing blow
• Clear a rush to earn new artifacts you keep forever
• Three difficulties — Easy with checkpoints, Standard with three lives, and Hard: one life, no mercy
• Jump straight into any rush you've reached
• Three built-in chiptune tracks, or play your own music
• Fully offline, no ads, no tracking

**Keywords (100 chars max, comma-separated):**
bullet hell,boss rush,pixel,retro,shmup,arcade,roguelike,dodge,chiptune,boss fight,8-bit

**Support URL:** (required — any page with a way to contact you, e.g. the same page as your privacy policy with your email)

**Copyright:** 2026 [your name or studio, e.g. Daggers Edge Games]

**Age rating:** answer Infrequent/Mild Cartoon or Fantasy Violence; everything else None.

**Review notes (optional):**
All content is bundled and plays offline. Tap/hold on the play area to attack; use the left stick to move and DASH to dodge. The optional "Upload your own song" feature only plays an audio file the user picks from their own device; nothing is uploaded or stored off-device.
